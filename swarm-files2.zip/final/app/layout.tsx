import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Script from "next/script";
import "./globals.css";

const inter = Inter({ subsets: ["latin", "cyrillic"] });

export const metadata: Metadata = {
  title: "ChatBot24 — AI-чатботы для бизнеса",
  description: "Разработка и внедрение AI-чатботов для автоматизации бизнеса. Telegram, WhatsApp, VK. Увеличьте продажи и сократите расходы на поддержку.",
  keywords: ["чатбот", "AI", "искусственный интеллект", "автоматизация", "Telegram", "WhatsApp", "VK"],
  authors: [{ name: "ChatBot24 Team" }],
  creator: "ChatBot24",
  publisher: "ChatBot24",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "ru_RU",
    url: "https://chatbot24.su/",
    siteName: "ChatBot24",
    title: "ChatBot24 — AI-чатботы для бизнеса",
    description: "Разработка и внедрение AI-чатботов для автоматизации бизнеса",
    images: [{
      url: "/og_image.png",
      width: 1200,
      height: 630,
      alt: "ChatBot24 — AI-чатботы для бизнеса"
    }],
  },
  twitter: {
    card: "summary_large_image",
    title: "ChatBot24 — AI-чатботы для бизнеса",
    description: "Разработка и внедрение AI-чатботов для автоматизации бизнеса",
    images: ["/og_image.png"],
  },
  verification: {
    yandex: "107072365",
  },
  alternates: {
    canonical: "https://chatbot24.su/",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <head>
        {/* Yandex.Metrika */}
        <Script
          id="yandex-metrika"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
              m[i].l=1*new Date();
              for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
              k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
              (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
              ym(107072365, "init", {
                clickmap:true,
                trackLinks:true,
                accurateTrackBounce:true,
                webvisor:true
              });
            `,
          }}
        />
        <noscript>
          <div>
            <img src="https://mc.yandex.ru/watch/107072365" style={{ position: "absolute", left: "-9999px" }} alt="" />
          </div>
        </noscript>

        {/* Schema.org Organization */}
        <Script
          id="schema-organization"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              "name": "ChatBot24",
              "url": "https://chatbot24.su",
              "logo": "https://chatbot24.su/logo_header.png",
              "description": "Разработка и внедрение AI-чатботов для бизнеса. Автоматизация продаж и поддержки клиентов.",
              "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+7-993-336-61-02",
                "contactType": "sales",
                "availableLanguage": ["Russian"],
                "areaServed": "RU"
              },
              "sameAs": [
                "https://vk.com/club237277911"
              ],
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "RU"
              }
            })
          }}
        />

        {/* Schema.org WebSite */}
        <Script
          id="schema-website"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "ChatBot24",
              "url": "https://chatbot24.su",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://chatbot24.su/search?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />

        {/* Schema.org FAQPage */}
        <Script
          id="schema-faq"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "Сколько стоит разработка чат-бота?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Стоимость разработки чат-бота варьируется от 0$ (конструкторы) до 20000$+ (индивидуальная разработка). Средний проект стоит 2000-5000$."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Какие мессенджеры поддерживаются?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Мы разрабатываем чат-ботов для Telegram, WhatsApp, VK, Viber и веб-чатов."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Сколько времени занимает разработка?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Простой чат-бот запускается за 1-2 недели, сложный проект с интеграциями — за 4-8 недель."
                  }
                }
              ]
            })
          }}
        />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  );
}
